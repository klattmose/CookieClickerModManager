Extracted from distribution version 1.0.0-beta16.

https://github.com/claviska/shoelace-css/releases/tag/1.0.0-beta16

Reused under the terms of the MIT license.
